package com.example.hpusbprintdiagnostic

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var usbManager: UsbManager
    private lateinit var output: TextView
    private val permissionAction = "com.example.hpusbprintdiagnostic.USB_PERMISSION"

    private val permissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != permissionAction) return
            val device = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
            }
            val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
            append("\nРазрешение USB: ${if (granted) "ПОЛУЧЕНО" else "ОТКЛОНЕНО"}")
            if (device != null && granted) append(describeDevice(device))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager

        output = TextView(this).apply {
            textSize = 14f
            setPadding(24, 18, 24, 18)
            text = "HP USB Print Diagnostic 1.0\nТелефон: ${Build.MANUFACTURER} ${Build.MODEL}\nAndroid: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n\nПодключи HP LaserJet Pro M102a кабелем OTG и нажми «Найти USB-принтер»."
        }

        val scanButton = Button(this).apply {
            text = "Найти USB-принтер"
            setOnClickListener { scanDevices() }
        }
        val refreshButton = Button(this).apply {
            text = "Обновить список"
            setOnClickListener { scanDevices() }
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            addView(scanButton, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            addView(refreshButton, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            addView(ScrollView(this@MainActivity).apply {
                addView(output)
            }, LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        setContentView(layout)

        val filter = IntentFilter(permissionAction)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(permissionReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(permissionReceiver, filter)
        }
        scanDevices()
    }

    private fun scanDevices() {
        val devices = usbManager.deviceList.values.toList()
        output.text = "Найдено USB-устройств: ${devices.size}\n"
        if (devices.isEmpty()) {
            append("\nУстройство не обнаружено.\nПроверь:\n• OTG включён в настройках Vivo\n• кабель поддерживает передачу данных, а не только зарядку\n• принтер включён\n• соединение Type-C ↔ USB-B надёжно подключено")
            return
        }

        devices.forEachIndexed { index, device ->
            append("\nУСТРОЙСТВО ${index + 1}")
            append(describeDevice(device))
            if (usbManager.hasPermission(device)) {
                append("\nРазрешение уже выдано.")
            } else {
                append("\nЗапрашиваю разрешение Android…")
                val intent = Intent(permissionAction).setPackage(packageName)
                val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
                val pendingIntent = PendingIntent.getBroadcast(this, device.deviceId, intent, flags)
                usbManager.requestPermission(device, pendingIntent)
            }
        }
    }

    private fun describeDevice(device: UsbDevice): String {
        val b = StringBuilder()
        b.append("\nНазвание: ${device.deviceName}")
        b.append("\nVendor ID: 0x${device.vendorId.toString(16).uppercase().padStart(4, '0')}")
        b.append("\nProduct ID: 0x${device.productId.toString(16).uppercase().padStart(4, '0')}")
        b.append("\nUSB device ID: ${device.deviceId}")
        b.append("\nКласс устройства: ${device.deviceClass} (${className(device.deviceClass)})")
        b.append("\nИнтерфейсов: ${device.interfaceCount}")

        for (i in 0 until device.interfaceCount) {
            val intf = device.getInterface(i)
            b.append("\n\n  Интерфейс $i:")
            b.append("\n  class=${intf.interfaceClass} (${className(intf.interfaceClass)}), subclass=${intf.interfaceSubclass}, protocol=${intf.interfaceProtocol}")
            b.append("\n  endpoints=${intf.endpointCount}")
            for (e in 0 until intf.endpointCount) {
                val ep = intf.getEndpoint(e)
                val direction = if (ep.direction == UsbConstants.USB_DIR_IN) "IN (к телефону)" else "OUT (от телефона)"
                val type = when (ep.type) {
                    UsbConstants.USB_ENDPOINT_XFER_BULK -> "BULK"
                    UsbConstants.USB_ENDPOINT_XFER_INT -> "INTERRUPT"
                    UsbConstants.USB_ENDPOINT_XFER_CONTROL -> "CONTROL"
                    UsbConstants.USB_ENDPOINT_XFER_ISOC -> "ISOCHRONOUS"
                    else -> "UNKNOWN"
                }
                b.append("\n    Endpoint $e: $direction, $type, maxPacket=${ep.maxPacketSize}")
            }
        }
        return b.toString()
    }

    private fun className(value: Int): String = when (value) {
        UsbConstants.USB_CLASS_PRINTER -> "PRINTER"
        UsbConstants.USB_CLASS_COMM -> "COMM"
        UsbConstants.USB_CLASS_HID -> "HID"
        UsbConstants.USB_CLASS_MASS_STORAGE -> "MASS_STORAGE"
        UsbConstants.USB_CLASS_VENDOR_SPEC -> "VENDOR_SPECIFIC"
        UsbConstants.USB_CLASS_PER_INTERFACE -> "PER_INTERFACE"
        else -> "OTHER"
    }

    private fun append(value: String) {
        output.append(value)
    }

    override fun onDestroy() {
        try { unregisterReceiver(permissionReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }
}
