package com.example.hpusbprintdiagnostic

import android.app.Activity
import android.app.PendingIntent
import android.content.*
import android.hardware.usb.*
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var manager: UsbManager
    private lateinit var output: TextView
    private val action = "com.example.hpusbprintdiagnostic.USB_PERMISSION"

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != action) return
            val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
            append("\nРазрешение USB: ${if (granted) "ПОЛУЧЕНО" else "ОТКЛОНЕНО"}")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        manager = getSystemService(Context.USB_SERVICE) as UsbManager
        output = TextView(this).apply {
            textSize = 15f
            setPadding(20, 16, 20, 16)
            text = "HP USB Print Diagnostic 1.1\n${Build.MANUFACTURER} ${Build.MODEL}\nAndroid ${Build.VERSION.RELEASE}"
        }
        val scan = Button(this).apply {
            text = "Найти USB-принтер"
            setOnClickListener { scanDevices() }
        }
        val status = Button(this).apply {
            text = "Проверить статус HP"
            setOnClickListener { checkStatus() }
        }
        val scroll = ScrollView(this).apply { addView(output) }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            addView(scan, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            addView(status, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            addView(scroll, LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        })
        val filter = IntentFilter(action)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else {
            @Suppress("DEPRECATION")
            registerReceiver(receiver, filter)
        }
        scanDevices()
    }

    private fun scanDevices() {
        val devices = manager.deviceList.values.toList()
        output.text = "HP USB Print Diagnostic 1.1\nНайдено USB-устройств: ${devices.size}\n"
        if (devices.isEmpty()) {
            append("\nПринтер не найден. Проверь OTG, кабель и питание.")
            return
        }
        devices.forEach { d ->
            append("\n${d.deviceName}\nVID=0x${d.vendorId.toString(16)} PID=0x${d.productId.toString(16)}")
            append("\nИнтерфейсов: ${d.interfaceCount}")
            for (i in 0 until d.interfaceCount) {
                val intf = d.getInterface(i)
                append("\nИнтерфейс $i: class=${intf.interfaceClass}, subclass=${intf.interfaceSubclass}, protocol=${intf.interfaceProtocol}")
                for (e in 0 until intf.endpointCount) {
                    val ep = intf.getEndpoint(e)
                    append("\n  Endpoint ${ep.address}: ${if (ep.direction == UsbConstants.USB_DIR_IN) "IN" else "OUT"}, type=${ep.type}, maxPacket=${ep.maxPacketSize}")
                }
            }
            if (manager.hasPermission(d)) append("\nUSB-разрешение уже выдано.")
            else {
                val intent = Intent(action).setPackage(packageName)
                val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
                manager.requestPermission(d, PendingIntent.getBroadcast(this, d.deviceId, intent, flags))
                append("\nЗапрошено разрешение USB.")
            }
        }
    }

    private fun checkStatus() {
        val device = manager.deviceList.values.firstOrNull { it.vendorId == 0x03F0 && it.productId == 0x612A }
        if (device == null) { append("\nHP M102a не найден."); return }
        if (!manager.hasPermission(device)) { append("\nНет USB-разрешения. Нажми поиск и разреши доступ."); return }
        val intf = (0 until device.interfaceCount).map { device.getInterface(it) }
            .firstOrNull { it.interfaceClass == UsbConstants.USB_CLASS_PRINTER }
        if (intf == null) { append("\nUSB Printer Class interface не найден."); return }

        var conn: UsbDeviceConnection? = null
        try {
            conn = manager.openDevice(device) ?: error("Не удалось открыть USB-соединение")
            if (!conn.claimInterface(intf, true)) error("Не удалось захватить интерфейс принтера")
            val bytes = ByteArray(1)
            // USB Printer Class GET_PORT_STATUS: class/interface IN, bRequest=1.
            val count = conn.controlTransfer(0xA1, 1, 0, intf.id, bytes, 1, 3000)
            if (count == 1) {
                val value = bytes[0].toInt() and 0xFF
                append("\n\nGET_PORT_STATUS: ОТВЕТ ПОЛУЧЕН")
                append("\nСырой статус: 0x${value.toString(16).uppercase().padStart(2, '0')}")
                append("\nИнтерфейс: ${intf.id}")
                append("\nПечать не запускалась.")
            } else {
                append("\n\nGET_PORT_STATUS не поддержан/нет ответа. Код: $count")
                append("\nUSB-соединение есть; возможно, требуется протокол HP.")
            }
            conn.releaseInterface(intf)
        } catch (e: Exception) {
            append("\nОшибка: ${e.message}")
        } finally { conn?.close() }
    }

    private fun append(s: String) { output.append(s) }

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        super.onDestroy()
    }
}
